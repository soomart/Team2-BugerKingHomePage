function filterFaq(category) {
            var faqItems = document.querySelectorAll('.faq_item');
            var visibleCount = 1; 
            faqItems.forEach(function(item) {
                if (category === '전체' || item.getAttribute('data-category') === category) {
                    item.classList.remove('hidden');
                    item.querySelector('.notice_no').textContent = visibleCount++;
                } else {
                    item.classList.add('hidden');
                }
            });
        }

        window.onload = function() {
            var allRadioButton = document.querySelector('input[value="전체"]');
            allRadioButton.checked = true;
            filterFaq('전체');
        }
		document.addEventListener("DOMContentLoaded", function() {
		    const faqItems = document.querySelectorAll(".faq_item");

		    faqItems.forEach(function(item) {
		        item.querySelector(".notice_row").addEventListener("click", function() {
		            item.classList.toggle("active");
		        });
		    });
		});