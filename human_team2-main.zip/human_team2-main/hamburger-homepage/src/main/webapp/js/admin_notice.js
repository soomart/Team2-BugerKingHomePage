/**
 * 공지사항 글 등록 함수 
 */
function regSubmit() {
	document.getElementById('form1').submit();
}

/*공지사항 글 수정페이지 이동하는 함수 */

function moveUpdate(seq) {
	location.href = '/hamburger/notice_list_admin_upadte_form.jsp?seq=' + seq;
}

/**
 * 공지사항 글 수정 함수 
 */
function updateSubmit() {
	document.getElementById('form1').submit();
}

/**
 * 공지사항 글 삭제 함수 
 */

/*function deletNotice(seq) {
	if(!confirm('정말' + seq + '번호의 게시글을 삭제하시겠습니까?')) {
		return false;
	}
		location.href = '/starbucks-hompage/admin_notice_delete_form.jsp?seq=' + seq;
}
*/