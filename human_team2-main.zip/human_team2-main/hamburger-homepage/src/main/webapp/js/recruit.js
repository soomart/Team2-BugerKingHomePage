/**
 * 
 */

function searchNotice() {
	const searchTextBoxEl = document.querySelector('#sch_bar');

	window.location.href = './recruit.jsp?search=' + searchTextBoxEl.value;
}