document.addEventListener('DOMContentLoaded', function () {
    // 버튼 클릭 시 팝업 열기
    const buttons = document.querySelectorAll('.btn_click1');
    buttons.forEach(button => {
        button.addEventListener('click', function () {
            const popupId = this.getAttribute('data-popup');
            const popup = document.getElementById(popupId);
            if (popup) {
                // 모든 팝업 닫기 (이전에 열려있던 것들 닫기)
                document.querySelectorAll('.popup').forEach(function(p) {
                    p.style.display = 'none';
                });
                // 선택한 팝업 열기
                popup.style.display = 'block';
            }
        });
    });

    // 팝업 닫기 버튼 클릭 시 팝업 닫기
    const closeButtons = document.querySelectorAll('.popup-close');
    closeButtons.forEach(button => {
        button.addEventListener('click', function () {
            const popup = this.closest('.popup');
            if (popup) {
                popup.style.display = 'none';
            }
        });
    });

    // 팝업 내에서 다른 팝업으로 이동하는 버튼 클릭 시 팝업 전환
    document.querySelectorAll('.popup-content button[data-target-popup]').forEach(function(button) {
        button.addEventListener('click', function() {
            const targetPopupId = this.getAttribute('data-target-popup');
            const targetPopup = document.getElementById(targetPopupId);
            if (targetPopup) {
                // 현재 팝업 닫기
                const currentPopup = this.closest('.popup');
                if (currentPopup) {
                    currentPopup.style.display = 'none';
                }
                // 선택한 다른 팝업 열기
                targetPopup.style.display = 'block';
            }
        });
    });

    // 팝업 바깥 부분 클릭 시 팝업 닫기
    const popups = document.querySelectorAll('.popup');
    popups.forEach(popup => {
        popup.addEventListener('click', function (e) {
            if (e.target === this) {
                this.style.display = 'none';
            }
        });
    });
});