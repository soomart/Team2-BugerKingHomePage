document.addEventListener('DOMContentLoaded', function () {
    const searchButton = document.querySelector('.new_board_search_btn');
    const searchTextBox = document.querySelector('#search_bar');

    searchButton.addEventListener('click', function (event) {
        event.preventDefault();

        const query = searchTextBox.value.trim(); 

        if (query) {
            window.location.href = 'http://localhost:8080/hamburger/notice_list.jsp?search=' + encodeURIComponent(query);
        } else {
            alert('검색어를 입력하세요.');
        }
    });
});

const postsPerPage = 10;  // 페이지당 게시글 수
    const posts = document.querySelectorAll('.post');
    const pagination = document.getElementById('pagination');
    const totalPages = Math.ceil(posts.length / postsPerPage);

    function showPage(page) {
        const start = (page - 1) * postsPerPage;
        const end = start + postsPerPage;

        posts.forEach((post, index) => {
            post.style.display = (index >= start && index < end) ? 'block' : 'none';
        });

        document.querySelectorAll('.pagination a').forEach(link => {
            link.classList.remove('active');
        });

        document.querySelector(`.pagination a[data-page="${page}"]`).classList.add('active');
    }

    function createPagination() {
        for (let i = 1; i <= totalPages; i++) {
            const pageLink = document.createElement('a');
            pageLink.textContent = i;
            pageLink.setAttribute('data-page', i);
            pageLink.href = '#';
            if (i === 1) pageLink.classList.add('active');

            pageLink.addEventListener('click', function(event) {
                event.preventDefault();
                const page = parseInt(this.getAttribute('data-page'));
                showPage(page);
            });

            const listItem = document.createElement('li');
            listItem.appendChild(pageLink);
            pagination.appendChild(listItem);
        }
    }

    createPagination();
    showPage(1);
	
	document.addEventListener('DOMContentLoaded', function() {
	    const pageLinks = document.querySelectorAll('.pagination a.num');

	    // 페이지 로드 시, 저장된 페이지를 active로 설정
	    const savedPage = localStorage.getItem('activePage');
	    if (savedPage) {
	        pageLinks.forEach(link => {
	            if (link.textContent === savedPage) {
	                link.classList.add('active');
	            }
	        });
	    }

	    pageLinks.forEach(link => {
	        link.addEventListener('click', function(event) {
	            // 모든 링크에서 active 클래스 제거
	            pageLinks.forEach(link => link.classList.remove('active'));

	            // 클릭된 링크에 active 클래스 추가
	            this.classList.add('active');

	            // 현재 페이지 번호를 로컬 스토리지에 저장
	            localStorage.setItem('activePage', this.textContent);
	        });
	    });
	});