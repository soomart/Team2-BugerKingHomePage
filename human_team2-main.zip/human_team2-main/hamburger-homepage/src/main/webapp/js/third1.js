document.addEventListener("DOMContentLoaded", function() {
    const hamburgerMenu = document.getElementById("hamburger-menu");
    const hamburgerMenuPage = document.getElementById("hamburger-menu-page");
    const closeButton = document.querySelector(".hamburger-menu-page .close");

    hamburgerMenu.addEventListener("click", function() {
        hamburgerMenuPage.classList.add("active"); // Add class to show the menu
    });

    closeButton.addEventListener("click", function() {
        hamburgerMenuPage.classList.remove("active"); // Remove class to hide the menu
    });
});
