/*
 * 페이지 스크롤에 따른 요소 제어

 * gsap사용법
 * gsap.to(요소, 지속시간, 옵션);
 *   ex) gsap.to('.to-top', .7, {opacity: 0});
*/
const badgeEl = document.querySelector('header .badges');
const toTopEl = document.querySelector('#to-top');
window.addEventListener('scroll', _.throttle(() => {
    console.log('scrollY:', window.scrollY);

    if (window.scrollY > 500) {
        // 배지 숨기기
        //badgeEl.style.display = 'none';
        gsap.to(badgeEl, .5, {opacity: 0, display: 'none'});

        // 위로가기 버튼 보이기
        gsap.to(toTopEl, .2, { x: 0 });
    } else {
        // 배지 보이기
        // badgeEl.style.display = 'block';
        gsap.to(badgeEl, .5, {opacity: 1, display: 'block'});

        // 위로가기 버튼 숨기기
        gsap.to(toTopEl, .2, { x: 100 });
    }
}, 500));   // 500ms마다 이벤트 발생

toTopEl.addEventListener('click', function() {
    gsap.to(
        window, 
        0.1, // 애니매이션 동작 시간
        {                 // 옵션
            scrollTo: 0,
        }
    );
});
