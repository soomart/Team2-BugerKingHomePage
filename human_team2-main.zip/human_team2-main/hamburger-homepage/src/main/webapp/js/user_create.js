/**
 * 
 */

function validateKoreanInput(event) {
    var input = event.target;
    input.value = input.value.replace(/[^ㄱ-힣]/g, '');
    } 
function validateNumberInput(event) {
    var input = event.target;
    input.value = input.value.replace(/[^0-9]/g, '');
        }
function validatePhoneInput(event) {
	var input = event.target;
	input.value = '010' + input.value.replace(/[^0-9]/g, '').substring(3);
	var message = document.getElementById("phone_message");
	
	if (input.value.length !== 11){
		message.style.color = "red";
		message.innerHTML = "핸드폰 번호를 11자리로 입력바랍니다.";
	} else {
		message.innerHTML= "";
	}
}
   
function regSubmit() {
	var requiredFields = [
                "id", "name", "phone_number", "password", "password2", "birthday",
                "email1", "sample6_postcode", "sample6_address", "sample6_detailAddress"
            ];
            for (var i = 0; i < requiredFields.length; i++) {
                var field = document.getElementById(requiredFields[i]);
                if (!field || field.value.trim() === "") {
                    if (field.id === "id") {
                alert("아이디를 입력해 주세요.");
            } else if (field.id === "name") {
                alert("이름을 입력해 주세요.");
            } else if (field.id === "phone_number") {
                alert("휴대폰 번호를 입력해 주세요.");
            } else if (field.id === "password") {
                alert("비밀번호를 입력해 주세요.");
            } else if (field.id === "password2") {
                alert("비밀번호 확인을 입력해 주세요.");
            } else if (field.id === "birthday") {
                alert("생년월일을 입력해 주세요.");
            } else if (field.id === "email1") {
                alert("이메일을 입력해 주세요.");
            } else if (field.id === "sample6_postcode") {
                alert("우편번호를 입력해 주세요.");
            } else if (field.id === "sample6_address") {
                alert("주소를 입력해 주세요.");
            } else if (field.id === "sample6_detailAddress") {
                alert("상세주소를 입력해 주세요.");
            }
            field.focus();
            return false;
        }
    }
 			var idcheck = document.getElementById("message").innerText;
 			var idInput = document.getElementById("id")
 			
 			if (idcheck === "이미 사용 중인 아이디입니다.") {
				alert("아이디가 중복됩니다.");
                idInput.focus();
                return false;
			}
			var phoneNumberInput = document.getElementById("phone_number");
            var phoneNumber = phoneNumberInput.value;
            

            if (phoneNumber.length !==11) {
                alert("휴대폰 번호를 11자리로 정확히 입력 바랍니다.");
                phoneNumberInput.focus();
                return false;
            }
 			
 			var passwordInput = document.getElementById("password");
        	var passwordConfirmInput = document.getElementById("password2");

            if (passwordInput.value !== passwordConfirmInput.value) {
                alert("비밀번호가 일치하지 않습니다.");
                passwordConfirmInput.focus();
                return false;
            }
           	var birthdayInput = document.getElementById("birthday");
            var birthday = birthdayInput.value;
            var birthdayPattern = /^[0-9]{8}$/;

            if (!birthdayPattern.test(birthday)) {
                alert("생년월일을 8자리 숫자로 입력 바랍니다.");
                birthdayInput.focus();
                return false;
            }    
            var email1Input = document.getElementById("email1");
            var email2Select = document.getElementById("email2");
            var email = email1Input.value + "@" + email2Select.value;
            
            var emailHiddenInput = document.createElement("input");
            emailHiddenInput.type = "hidden";
            emailHiddenInput.name = "email";
            emailHiddenInput.value = email;
            document.getElementById("form1").appendChild(emailHiddenInput);         
            
	// form태그 안의 action값으로 이동
	document.getElementById('form1').submit();

}

function sample6_execDaumPostcode() {
        new daum.Postcode({
            oncomplete: function(data) {
                // 팝업에서 검색결과 항목을 클릭했을때 실행할 코드를 작성하는 부분.

                // 각 주소의 노출 규칙에 따라 주소를 조합한다.
                // 내려오는 변수가 값이 없는 경우엔 공백('')값을 가지므로, 이를 참고하여 분기 한다.
                var addr = ''; // 주소 변수
                var extraAddr = ''; // 참고항목 변수

                //사용자가 선택한 주소 타입에 따라 해당 주소 값을 가져온다.
                if (data.userSelectedType === 'R') { // 사용자가 도로명 주소를 선택했을 경우
                    addr = data.roadAddress;
                } else { // 사용자가 지번 주소를 선택했을 경우(J)
                    addr = data.jibunAddress;
                }

                // 사용자가 선택한 주소가 도로명 타입일때 참고항목을 조합한다.
                if(data.userSelectedType === 'R'){
                    // 법정동명이 있을 경우 추가한다. (법정리는 제외)
                    // 법정동의 경우 마지막 문자가 "동/로/가"로 끝난다.
                    if(data.bname !== '' && /[동|로|가]$/g.test(data.bname)){
                        extraAddr += data.bname;
                    }
                    // 건물명이 있고, 공동주택일 경우 추가한다.
                    if(data.buildingName !== '' && data.apartment === 'Y'){
                        extraAddr += (extraAddr !== '' ? ', ' + data.buildingName : data.buildingName);
                    }
                    // 표시할 참고항목이 있을 경우, 괄호까지 추가한 최종 문자열을 만든다.
                    if(extraAddr !== ''){
                        extraAddr = ' (' + extraAddr + ')';
                    }
                    // 조합된 참고항목을 해당 필드에 넣는다.
                    document.getElementById("sample6_extraAddress").value = extraAddr;
                
                } else {
                    document.getElementById("sample6_extraAddress").value = '';
                }

                // 우편번호와 주소 정보를 해당 필드에 넣는다.
                document.getElementById('sample6_postcode').value = data.zonecode;
                document.getElementById("sample6_address").value = addr;
                // 커서를 상세주소 필드로 이동한다.
                document.getElementById("sample6_detailAddress").focus();
            }
        }).open();
    }   

function checkUserid() {
	var userid = document.getElementById("id").value.trim();
    var message = document.getElementById("message");
            
    if (userid === "") {
		message.innerText = "";
		return;
	}
			
		var xhr = new XMLHttpRequest();
        xhr.open("GET", "user_idCheck.jsp?userid=" + encodeURIComponent(userid), true);
    	xhr.onreadystatechange = function () {
        	if (xhr.readyState === 4 && xhr.status === 200) {
		        var response = xhr.responseText.trim();
		        if (response === "available") {
		            message.innerText = "사용 가능한 아이디입니다.";
		            message.style.color = "blue";
		        } else {
		            message.innerText = "이미 사용 중인 아이디입니다.";
		            message.style.color = "red";
		        }
       	}
    };
    xhr.send();
}
        
function checkPassword() {
            var passwordInput = document.getElementById("password");
            var passwordConfirmInput = document.getElementById("password2");
            var message = document.getElementById("passwordMessage");

            if (passwordInput.value.trim() !=="" && passwordConfirmInput.value.trim() !=="" && passwordInput.value === passwordConfirmInput.value) {
                message.style.color = "blue";
                message.innerHTML = "비밀번호가 일치합니다.";
      		} else if (passwordInput.value.trim() === "" && passwordConfirmInput.value.trim() === ""){ 
				message.innerText = "";
            } else {
				message.style.color = "red";
                message.innerHTML = "비밀번호가 일치하지 않습니다.";
			}
        }
        
