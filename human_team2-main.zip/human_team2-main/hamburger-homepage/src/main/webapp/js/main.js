console.log('burgerking main.js파일');

const swiper_container = document.querySelector(".swiper-container");
const swiper_wrapper = document.querySelector(".swiper-container");
const swiper_slide = document.querySelectorAll(".swiper-slide");

let imageCount = 0;
let currentIndex = 0;
let currentPosition = 0;

window.onload = () => {
    imageCount = swiper_wrapper.children.length - 0;
    setInterval(autoSlide, 4000);
}

function showSlide(event, swiper_slide) {
    for (let i = 0; i < swiper_slide.length; i++) {
        if (swiper_slide[i] == event.target) {
            currentIndex = i;
            break;
        }
    }
}

function activeSlide() {
    for (let i = 0; i < swiper_slide.length; i++) {
        if (i == currentIndex) swiper_slide[i].classList.add("active");
        else swiper_slide[i].classList.remove("active");
    }
}

function moveSlide() {
    swiper_wrapper.querySelector("ul").style = `transform: translate3d(${currentPosition}px, 0, 0); transition: all 0.5s ease 0s`;
    activeSlide();
}

function calcImagePosition() {
    currentPosition = currentIndex * (-1440);
}

function imageIndexUp() {
    currentIndex++;
    if (currentIndex > imageCount - 1) currentIndex = 0;
}

function imageIndexDown() {
    currentIndex--;
    if (currentIndex < 0) currentIndex = imageCount - 1;
}

function autoSlide() {
    imageIndexUp();
    calcImagePosition();
    moveSlide();
}

const swiperPromotion = new Swiper('.wrap .swiper-container', {
    // Optional parameters
    slidesPerView: 1, // 한번에 보여줄 슬라이드 개수 (기본값은 1)
    loop: true, // 반복 재생 여부
    // autoplay: {
    //     delay: 5000, // 5초마다 자동 재생
    // }
    //pagination: {
        //el: '.swiper-pagination', // 페이지 번호 요소 선택자
        //clickable: true, // 사용자의 페이지 번호 요소 제어 가능 여부
    //},
    navigation: {
        prevEl: '.wrap .btn_prev',
        nextEl: '.wrap .btn_next',
    },
}); 

const thisYear = document.querySelector('.this-year');
thisYear.textContent = new Date().getFullYear(); // 현재 년도 표시  